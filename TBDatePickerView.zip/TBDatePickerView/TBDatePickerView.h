//
//  TBDatePickerView.h
//  Car
//
//  Created by Joyang on 16/9/12.
//  Copyright © 2016年 杨童彪. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBDatePickerView : UIView


@property (nonatomic,copy)void(^callBack)(NSInteger year,NSInteger month,NSInteger day);
@property (nonatomic, strong) NSString *fromDateString;
@property (nonatomic, strong) NSString *endDateString;

/**
 *  显示视图
 */
- (void)show;

/**
 *  销毁视图
 */
- (void)dismiss;

@end
